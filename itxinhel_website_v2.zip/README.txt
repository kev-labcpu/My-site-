Features:
- Partikel über dem Namen
- Kleiner Mauspunkt
- Spotify-ähnlicher Player
- 3 Songs möglich

Lege in /songs:
song1.mp3 (Miss You)
song2.mp3
song3.mp3

Musikideen:
- The Weeknd - Blinding Lights
- Joji - Glimpse of Us
- Arctic Monkeys - I Wanna Be Yours
